module.exports = {
    mongodbUrl: 'mongodb://localhost:27017/weblog',
    secretKey: '/\/\0H@mm@|)'
}