module.exports = {
    mongodbUrl: 'mongodb+srv://mammadsafar:<t5EkkC3znwG14i9w>@qiftolly-blog.r4jrc.mongodb.net/myFirstDatabase?retryWrites=true&w=majority',
    secretKey: '/\/\0H@mm@|)'
}