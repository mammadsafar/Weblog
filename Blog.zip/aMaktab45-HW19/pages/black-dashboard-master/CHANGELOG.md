# Change Log

## [1.0.1] 2018-09-01
### Bug Fixing
  - responsive issues
  - changes on RTL Page
  - added Upgrade to PRO Page
  - navbar & sidebar fixes

## [1.0.0] 2018-08-14
### Original Release
