$(".menu").click(function () {
    $(this).parent().toggleClass("close");
});